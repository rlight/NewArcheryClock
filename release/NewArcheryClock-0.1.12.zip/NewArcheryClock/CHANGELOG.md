# Changelog

## 0.1.12

- **Setup now updates Node.js too.** Re-running `windows\install.bat` or `mac/install.command` on a computer
  that already has Node.js upgrades it to the current LTS (winget on Windows, Homebrew on a Mac) instead of
  leaving the version it was first installed with. The clock itself is updated by the in-app updater; the
  runtime underneath it was not, so security fixes in Node.js (such as CVE-2026-111497, fixed in Node 24.22.1)
  never reached a range PC. After installing this release, run `install.bat` once on the clock computer.

## 0.1.11

- **New sound: Default (loud).** The same tone as Default, about 4 dB louder. The original
  is already near the maximum level a recording can have, so this version is soft-clipped to stay near
  full volume for its whole length. It sounds a little harsher, like a buzzer, and carries further on an
  outdoor range. Pick it under Sound on the control page. The volume slider still works with it.

## 0.1.10

- **New theme: Archery Range.** An indoor range: panelled wall, warm overhead lights, target-face
  lamps and wooden plaques for the End and detail letters.
- **Between ends, an archer shoots.** On the time screen between ends, an archer on the left takes an
  arrow from his quiver, draws and aims at the target on the right. His aim creeps up, and the arrow
  thunks into the wall above the target. He looks up at it and scratches his head. Up to five arrows
  pile up in the wall before they're cleared. To make room, this theme leaves the date off that screen.

## 0.1.9

- **Halloween: more witch.** She's bigger and now flies back and forth: across the screen, a turn
  off-screen, and back the other way.
- **Halloween: a black cat** pops its head in from the bottom or a side edge every so often, looks
  around and blinks, then ducks away. Like the witch, only on the time-and-date screen between ends.

## 0.1.8

- **Halloween: a witch on her broomstick** (with her black cat) now flies across the screen while the
  clock is idle between ends showing the time and date. She keeps to the lower half, so she never covers
  the time, and she's gone as soon as an end starts.
- **LPYA Sunset: the match-start countdown can no longer spill out of the bottom of its box.** The
  numbers now shrink to fit the box's height as well as its width, whatever font or screen the clock uses.

## 0.1.7

- **Fixes the control page crashing on phones** ("A problem repeatedly occurred") when scrolling the
  Display tab: theme cards now show still pictures instead of nine live copies of the display.

## 0.1.6

- **Three new display themes:**
  - **Arctic Blast** — the winter series look: northern lights over icy mountains, falling snow,
    ice-crystal lamps and navy shield badges.
  - **Christmas** — snowy night, twinkling tree and presents, ornament lamps, gift-tag letters.
  - **Thanksgiving** — harvest evening with drifting leaves, hay bales and a turkey; lantern lamps on a
    wooden board; "Happy Thanksgiving" between ends.
- Halloween: the time between ends no longer risks running into the pumpkin lamps with wider fonts.

## 0.1.5

- **Fixes choosing a theme on the Display tab.** With six themes, the live preview cards used up all the
  connections a browser allows to one server, so the change you picked was never sent. The previews now
  get their updates from the page itself.

## 0.1.4

- **Fixes the Windows "Install update" button.** The installer is now started independently of the clock,
  and the clock only shuts down once the installer reports that it is running; if it doesn't start within
  15 seconds, the update is cancelled and the clock keeps running.
- **Clocks on 0.1.1–0.1.3 on Windows must install 0.1.4 by hand once** (stop the clock, unzip
  NewArcheryClock-0.1.4.zip over the folder, start it). Later updates then work from the button.

## 0.1.3

- **Halloween theme** (Display tab → Theme): haunted night with a full moon, bats, fog, a graveyard and
  jack-o'-lanterns as the traffic light; the big numbers glow in the phase colour. Looks best with the
  "Chiller" font (installed with Microsoft Office on Windows); falls back to Impact.

## 0.1.2

- **Three new display themes** (Display tab → Theme):
  - **LPYA Sunset** — Lower Providence Youth Archery colours: sunset over the mountains, eagle, pines and
    the shield logo, with big white numbers on a panel tinted in the phase colour and a shield-shaped light.
  - **Stadium** — modern sports scoreboard: huge condensed numbers, phase header (WALK UP / SHOOT / LAST 30)
    and a progress bar that drains as time runs out.
  - **Daylight** — the whole screen turns red, green or yellow with giant numbers; the most visible outdoors.
- Themes now know the length of the yellow warning period, so they can say "LAST 30" exactly.

## 0.1.1

- **Updates from the control page.** The clock checks GitHub for new versions; *Start-up & connection →
  Updates* shows what's new with an **Install update** button (between ends only). Settings, rounds and
  the password are kept, the old version is backed up, and it's put back automatically if the new one
  doesn't start. Optional: install waiting updates automatically when the computer starts.

## 0.1.0

- First release: clock engine (target rounds, finals, 25m1P, manual), Classic and Retro LED themes,
  web control page, national anthem, time of day between ends, password for other devices,
  private-range music controls, Windows and Mac scripts.
